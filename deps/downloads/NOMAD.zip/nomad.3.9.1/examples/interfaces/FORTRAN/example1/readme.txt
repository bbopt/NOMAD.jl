Run the NOMAD library with a FORTRAN black-box routine.

This examples works on a X system with g++ and gfortran.

Type 'make' and then './test.exe'.