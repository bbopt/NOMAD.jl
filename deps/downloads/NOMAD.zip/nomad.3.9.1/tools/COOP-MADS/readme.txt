Procedure for Unix/Linux/mac OSX

1- Set the NOMAD_HOME environment variable
2- Compile with the command make
3- Go to one of the problem directory
4- Compile the black box (g++ -o bb.exe bb.cpp)
5- Run coopmads  (mpirun -np 3 ../../coopmads.exe param.txt) 
