The test script is for OSX and Linux only

1- Set the NOMAD_HOME environment variable
2- Execute the perl script (perl ./runNomadAll_parallel.pl 4)
3- Check the execution logs if necessary
